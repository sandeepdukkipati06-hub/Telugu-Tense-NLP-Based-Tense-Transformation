document.addEventListener('DOMContentLoaded', function () {
    const predictButton = document.getElementById('predict-button');
    const convertButton = document.getElementById('convert-button');
    const outputDiv = document.getElementById('output');
    const loadingSpinner = document.getElementById('loading-spinner');
    let selectedTenseButton = null;

    // Show loading spinner
    function showLoadingSpinner() {
        loadingSpinner.style.display = 'block';
    }

    // Hide loading spinner
    function hideLoadingSpinner() {
        loadingSpinner.style.display = 'none';
    }

    // Handle the predict button click
    predictButton.addEventListener('click', function () {
        const sentence = document.getElementById('sentence').value;
        if (!sentence.trim()) {
            alert('Please enter a sentence.');
            return;
        }

        // Show loading spinner
        showLoadingSpinner();

        // Send the sentence to the server for tense prediction
        fetch('/predict_and_convert', {
            method: 'POST',
            body: new URLSearchParams({ sentence: sentence, tense: 'predict' })
        })
        .then(response => response.json())
        .then(data => {
            hideLoadingSpinner(); // Hide spinner after receiving response

            document.getElementById('predicted-tense').style.display = 'block';
            document.getElementById('predicted-tense-output').textContent = data.predicted_tense;
            document.getElementById('predicted-tense-output').style.display = 'block';

            const tenseButtonsDiv = document.getElementById('tense-buttons');
            tenseButtonsDiv.innerHTML = '';
            const tenses = [
                'Simple Present', 'Present Continuous', 'Present Perfect', 'Present Perfect Continuous',
                'Simple Past', 'Past Continuous', 'Past Perfect', 'Past Perfect Continuous',
                'Simple Future', 'Future Continuous', 'Future Perfect', 'Future Perfect Continuous'
            ];

            tenses.forEach(tense => {
                const button = document.createElement('button');
                button.textContent = tense;
                button.className = 'tense-button';

                button.addEventListener('click', function () {
                    if (selectedTenseButton) {
                        selectedTenseButton.classList.remove('highlight');
                    }
                    button.classList.add('highlight');
                    selectedTenseButton = button;
                    convertButton.disabled = false;
                    convertButton.dataset.selectedTense = tense;
                });

                tenseButtonsDiv.appendChild(button);
            });
        })
        .catch(error => {
            hideLoadingSpinner(); // Hide spinner in case of an error
            console.error('Error during prediction:', error);
            alert('Error predicting tense.');
        });
    });

    // Handle the convert button click
    convertButton.addEventListener('click', function () {
        const sentence = document.getElementById('sentence').value;
        const targetTense = convertButton.dataset.selectedTense;

        if (!targetTense) {
            alert('Please select a target tense.');
            return;
        }

        convertButton.disabled = true;
        showLoadingSpinner(); // Show spinner before conversion

        fetch('/predict_and_convert', {
            method: 'POST',
            body: new URLSearchParams({ sentence: sentence, tense: targetTense })
        })
        .then(response => response.json())
        .then(data => {
            hideLoadingSpinner(); // Hide spinner after conversion

            document.getElementById('converted-sentence-output').textContent = `Converted Sentence: ${data.converted_sentence}`;
            document.getElementById('telugu-translation-output').textContent = `Telugu Translation: ${data.translated_sentence}`;
            outputDiv.style.display = 'block';
            convertButton.disabled = false;

            if (selectedTenseButton) {
                selectedTenseButton.classList.remove('highlight');
            }
        })
        .catch(error => {
            hideLoadingSpinner(); // Hide spinner in case of an error
            console.error('Error during conversion:', error);
            alert('Error converting tense.');
            convertButton.disabled = false;
        });
    });
});
