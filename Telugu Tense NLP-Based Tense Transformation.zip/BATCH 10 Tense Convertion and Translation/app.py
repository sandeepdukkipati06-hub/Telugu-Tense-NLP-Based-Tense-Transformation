import os
import pickle
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, session
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.sequence import pad_sequences
import pandas as pd
import spacy
import mysql.connector
from werkzeug.security import generate_password_hash, check_password_hash
from transformers import MBartForConditionalGeneration, MBart50TokenizerFast

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Change this to a strong secret key

# Paths for saved model, tokenizer, and label encoder
MODEL_PATH = 'models/lstm_tense_model_12.h5'
TOKENIZER_PATH = 'models/tokenizer_12.pkl'
LABEL_ENCODER_PATH = 'models/label_encoder.pkl'

# Load the model, tokenizer, and label encoder
model = tf.keras.models.load_model(MODEL_PATH)

with open(TOKENIZER_PATH, 'rb') as handle:
    tokenizer = pickle.load(handle)

with open(LABEL_ENCODER_PATH, 'rb') as handle:
    label_encoder = pickle.load(handle)

# Load translation model and tokenizer
translation_model_checkpoint = "aryaumesh/english-to-telugu"
translation_tokenizer = MBart50TokenizerFast.from_pretrained(translation_model_checkpoint)
translation_model = MBartForConditionalGeneration.from_pretrained(translation_model_checkpoint)

# Get the max sequence length used in training
MAX_SEQUENCE_LENGTH = 21  # Change this to match the length used during training

# Load verb forms from the XLSX file
def load_verb_forms(file_path):
    verb_forms = {}
    df = pd.read_excel(file_path)
    for _, row in df.iterrows():
        verb_forms[row['Base form']] = {
            'base': row['Base form'],
            'third_person': row['Third person singular'],
            'past': row['Simple Past'],
            'participle': row['Past participle'],
            'gerund': row['Present participle / Gerund']
        }
    return verb_forms

# Load the verb forms dataset
file_path = 'datasets/Extended_Verbs.xlsx'  # Update this path as necessary
verb_forms = load_verb_forms(file_path)

# Initialize spaCy
nlp = spacy.load("en_core_web_sm")

# Function to determine the correct auxiliary verb
def determine_auxiliary(subject):
    doc = nlp(subject)
    if len(doc) == 1 and doc[0].pos_ == "PROPN":
        return "is"  # Proper nouns (like names) are typically singular.
    elif subject.lower() in ["he", "she", "it"]:
        return "is"
    elif subject.lower() == "i":
        return "am"
    elif doc[0].tag_ == "NNP":
        return "is"  # Singular proper nouns (names).
    else:
        return "are"  # for plural subjects and "you"

# Function to convert tenses
def convert_tense(sentence, target_tense):
    doc = nlp(sentence)
    subject = None
    obj = None
    verb = None

    # Find subject, verb, and object
    for token in doc:
        if token.dep_ in ["nsubj", "nsubjpass"]:  # subject
            subject = token.text
        elif token.dep_ == "dobj" or token.dep_ == "pobj" or token.dep_ == "attr":  # object or complement
            obj = ' '.join([child.text for child in token.subtree])
        elif token.pos_ == "VERB":  # verb
            verb = token.lemma_

    if not subject or not verb:
        return "Could not find a valid subject or verb."

    # Get verb forms from the dataset
    verb_info = verb_forms.get(verb)
    if not verb_info:
        return "Verb not found in the dataset."

    # Determine auxiliary verbs based on the subject
    auxiliary = determine_auxiliary(subject)

    # Convert the verb based on target tense
    if target_tense == "Simple Present":
        new_verb = verb_info['third_person'] if subject.lower() in ['he', 'she', 'it'] or nlp(subject)[0].tag_ == "NNP" else verb_info['base']
        return f"{subject} {new_verb} {obj or ''}".strip()

    elif target_tense == "Present Continuous":
        new_verb = verb_info['gerund']
        return f"{subject} {auxiliary} {new_verb} {obj or ''}".strip()

    elif target_tense == "Present Perfect":
        new_verb = verb_info['participle']
        return f"{subject} has {new_verb} {obj or ''}" if subject.lower() in ['he', 'she', 'it'] else f"{subject} have {new_verb} {obj or ''}".strip()

    elif target_tense == "Past Perfect":
        new_verb = verb_info['participle']
        return f"{subject} had {new_verb} {obj or ''}".strip()

    elif target_tense == "Simple Past":
        new_verb = verb_info['past']
        return f"{subject} {new_verb} {obj or ''}".strip()

    elif target_tense == "Simple Future":
        new_verb = verb_info['base']
        return f"{subject} will {new_verb} {obj or ''}".strip()

    elif target_tense == "Past Continuous":
        new_verb = verb_info['gerund']
        was_were = "was" if subject.lower() in ['i', 'he', 'she', 'it'] or nlp(subject)[0].tag_ == "NNP" else "were"
        return f"{subject} {was_were} {new_verb} {obj or ''}".strip()

    elif target_tense == "Future Continuous":
        new_verb = verb_info['gerund']
        return f"{subject} will be {new_verb} {obj or ''}".strip()

    elif target_tense == "Future Perfect":
        new_verb = verb_info['participle']
        return f"{subject} will have {new_verb} {obj or ''}".strip()

    elif target_tense == "Present Perfect Continuous":
        new_verb = verb_info['gerund']
        return f"{subject} has been {new_verb} {obj or ''}" if subject.lower() in ['he', 'she', 'it'] else f"{subject} have been {new_verb} {obj or ''}".strip()

    elif target_tense == "Past Perfect Continuous":
        new_verb = verb_info['gerund']
        return f"{subject} had been {new_verb} {obj or ''}".strip()

    elif target_tense == "Future Perfect Continuous":
        new_verb = verb_info['gerund']
        return f"{subject} will have been {new_verb} {obj or ''}".strip()

    else:
        return "Tense conversion not supported."
  

# MySQL Database Connection
def get_db_connection():
    connection = mysql.connector.connect(
        host='localhost',
        user='root',
        password='root',
        database='jagadeesh'  # Change to your database name
    )
    return connection
  
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict_and_convert', methods=['POST'])
def predict_and_convert():
    try:
        # Get the sentence and target tense from the frontend
        sentence = request.form['sentence']
        target_tense = request.form['tense']

        # Step 1: Predict the tense
        seq = tokenizer.texts_to_sequences([sentence])
        padded_seq = pad_sequences(seq, maxlen=MAX_SEQUENCE_LENGTH)
        prediction = model.predict(padded_seq)
        predicted_label_idx = np.argmax(prediction)
        predicted_tense = label_encoder.inverse_transform([predicted_label_idx])[0]

        # Step 2: Convert the sentence to the target tense
        converted_sentence = convert_tense(sentence, target_tense)

        # Step 3: Translate the converted sentence to Telugu
        inputs = translation_tokenizer(converted_sentence, return_tensors="pt")
        outputs = translation_model.generate(**inputs)
        translated_sentence = translation_tokenizer.decode(outputs[0], skip_special_tokens=True)

        # Return both the predicted tense, converted sentence, and translated sentence as JSON
        return jsonify({
            "predicted_tense": predicted_tense,
            "converted_sentence": converted_sentence,
            "translated_sentence": translated_sentence
        })

    except Exception as e:
        return jsonify({"error": str(e)})
    
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        name = request.form['name']
        username = request.form['username']
        password = request.form['password']
        hashed_password = generate_password_hash(password)

        connection = get_db_connection()
        cursor = connection.cursor()

        try:
            # Check if the username already exists
            cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
            existing_user = cursor.fetchone()

            if existing_user:
                flash('Username already exists. Please choose a different one.', 'danger')
                return redirect(url_for('signup'))

            # Insert new user into the database
            cursor.execute("INSERT INTO users (name, username, password) VALUES (%s, %s, %s)", 
                           (name, username, hashed_password))
            connection.commit()
            flash('Signup successful! You can now login.', 'success')
            return redirect(url_for('login'))
        except mysql.connector.Error as err:
            flash(f'Error: {err}', 'danger')
            connection.rollback()  # Rollback the transaction if there's an error
        finally:
            cursor.close()
            connection.close()

    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        connection = get_db_connection()
        cursor = connection.cursor()

        cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        user = cursor.fetchone()

        if user and check_password_hash(user[3], password):  # user[3] is the password field
            session['username'] = username  # Store the username in the session
            flash('Login successful!', 'success')  # Add category for success
            return redirect(url_for('main'))
        else:
            flash('Invalid username or password.', 'danger')  # Add category for error

        cursor.close()
        connection.close()

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.pop('username', None)  # Remove the username from the session
    flash('You have been logged out.')
    return redirect(url_for('index')) 

@app.route('/main', methods=['GET'])
def main():
    username = session.get('username')
    print("Current session username:", username)  # Debug line
    return render_template('main.html', username=username)

    
if __name__ == '__main__':
    app.run(debug=False, threaded=True)
